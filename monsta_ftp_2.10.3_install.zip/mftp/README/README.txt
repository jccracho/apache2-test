For full Monsta FTP install and usage documentation, please visit:
https://www.monstaftp.com/guides/